  #Names: Chris Macleman - Alex MacLellan
  #Matirculation: 140020909 - 160016453


logging()
{
      echo "hello, please enter your username and password"
    echo "username: "
    read username
    


if grep $username UseAndPass
    then
    echo "username found, please enter a password"
    echo "password: "

    
    case $username in
      Chris) pass=12345      
      ;;
      Alex) pass=22222
      ;;
      Jon) pass=33333      
      ;;
      Iain) pass=44444      
      ;;
    esac
  read password
    count=0

  while [ "$password" != "$pass" ]; do
     if [[ count == 3 ]]; then
       echo "3 passwords attempted, exiting program"
       exit
     fi
     echo "Sorry that password is wrong, please try again"
    read password
    count++
  done  
  menu


else
    echo "username not found. Exiting program"
    exit 0
fi
}




function writeToLog()
{
    #writes who has accessed the file 
    cd repository

       echo "--------------------------" >> Log.txt
       echo "$(whoami)" >> Log.txt
       echo "$(date)" >> Log.txt
       echo "$input"
       cd ..
}

#function that uses a for loop to look at the files in a directory
function listFiles()
{
        for file in $(ls $dir)
       do
       [ -f $file ] && echo "$file is File"
       [ -d $file ] && echo "$file is Directory"
       done  
}

#uses the list files function and shows all of the information to the user then return to
#repository

function seeFiles()
{
    
    listFiles
    echo "press enter to continue.."
    read
    repository
    break;
}

function commit()
{
        clear

       echo "List of files in your folder"
       echo " "

       #Lists the files and directories in the Repository.       
       listFiles 
             
      #Imports a file from wherever to the Repository folder.
      echo "-----------------------------------------------------"
      echo "Please enter the file you wish to commit to the repository"
      echo "Remember the file must be on this computer"
      echo "-----------------------------------------------------"
      read input
      echo "Please input the path to your Repository"


      read RPATH
      if [ -z "$RPATH" ]; then
          echo "no path entered, returning to main menu"
          menu
      fi

    #combines both variable to search for the file name
      completeFilePath=$RPATH"/"$input
      

    #If statement to check if the file is in the directory or not

if [ -e "$completeFilePath" ]; 
    
    then
        echo "file already exists, are you sure you want to overwrite it?"
        
        read yOrN
           if [[ $yOrN == "y" || $yOrN == "Y" ]]; then
            cd repository
            echo "Changes made are" >> Log.txt
            echo "=======================" >> Log.txt
            #compares the differences between the two files
            diff $completeFilePath $input >> log.txt
            cd ..
            cp $input $RPATH
                elif [[ $yOrN == "n" || $yOrN == "N" ]]; then
                echo "not overwriting file. Returning to main menu"
        menu
        else 
            echo "incorrect input returning to main menu"
            menu
            fi

    else        
     cp $input $RPATH
    
    
fi
      

      writeToLog
      echo "==========IMPORT==========" >> Log.txt
      date=$(date +%d-%m-%Y-H:%M)
      mkdir $date
      cp -R $RPATH/. $date/
      
      echo "Auto archive complete, press enter to continue"
      zip -r $date $date
      rm -r $date
      read
      
      menu
      break
}

function checkout()
{   
      #Lists the files and directories in the Repository.
      cd Repository
     listFiles

      echo "--------------------------"
      echo "Enter the name of the file you would like to Export. "
      echo "Remember the file must be in the Directory"
      echo "--------------------------"

      #Takes file name and exports the file to home.
      echo "Please Enter File Name"
      read expor

      echo "Please input the path to the file you'd like to checkout to"
      read RPATH



if [ -e "$expor" ]; 
      then

      cp $expor $RPATH

      echo "Sending to Folder"
      echo "--------------------------"
      echo "press enter to continue"
      read
      writeToLog
      echo "==========EXPORT==========" >> Log.txt
      cd ..
      menu
      break

      
      
  else
    echo "file doesn't exist. Returning to main menu. Press enter to continue"
    read
    cd ..
    menu
    break  
    
fi
}

#function for the user to create a file
editFile()
{
clear
listFiles
echo "Please enter the name of the file you would like to edit from the above list"
read input

#checks to see if there is a file in the directory
if [ -e $input ]; then
    gedit $input&       
    repository
else
    echo "sorry there's no file by the name. Returning to menu"
    read
    repository
    break
fi

}

fileCount()
{
  ls -l |  wc -l
}


#delete a file from the repository
delete()
{
   clear
    listFiles
    echo "Please enter the name of the file you would like to delete from the above list"
    read input 

    #checks to see if there is a file with the correct name in the directory
    if [ -e $input ]; then
      #double checks with the user if they're sure they want to delete the file
    echo "Are you sure you wish to delete $input?"
        read yOrN
           if [[ $yOrN == "y" || $yOrN == "Y" ]]; then
            rm -r $input
            repository
            break
            
        elif [[ $yOrN == "n" || $yOrN == "N" ]]; then
                echo "returning to repository menu"
                
            else
                echo "incorrect input, returning to repository menu"
                
            fi

else
    echo "sorry there's no file by the name. Returning to menu"
    read
    repository
    break
fi
repository
break

}


#How to function, explains to the user how to use the system.
function howTo
{
  clear

  echo "Hello and welcome to a quick how to use the repository"
  echo "before you start you'll need to know the file path of your repository"
  echo "and you'll need to know where you want the information to be stored"
  echo "if you know that then you're good to go"
  echo "please select one of the options below"
  
echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
echo "|1. Learn how to commit a file                       |"
echo "|2. Learn how to check out a file                    |"
echo "|3. Learn how to List all of the files               |"
echo "|4. Learn how to edit a file                         |"
echo "|5. Learn how to Delete a file in the repository     |"
echo "|6. See changes that have been made                  |"
echo "|7. Exit to main menu                                |"                   
echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "

read input
until (($input < 8 && $input > 0))
do
    echo "incorrect input, please try again"
    echo "please input a number between 1-7"
    read input;
done

case $input in
  1)  
  clear
  echo "To use the repository please press 1 at the main menu"
  echo "from here you'll have a few options. If you haven't ever used the repository"
  echo "then you'll need to commit a file before you can check one out"
  read
  clear
  echo "now that you're on the commit menu you'll be shown a list of files that are in"
  echo "your current directory. Pick one of these and type the file name"
  echo "once you've entered that you'll be asked to enter where your repository is."
  echo "After you've entered that a back up will be made of the file you've just commited"
  echo "it will also be zipped so it doesn't take up as much space!"
  howTo
  break
  ;;

  2)
  clear
  echo "now that you have a file in your repository you can check this out by going to the "
  echo "repository menu. Once here press 1 and you'll gain access to the files inside of it."
  read
  clear
  echo "now that you're here you'll be presented with a list of items that are inside of the"
  echo "repository. "
  echo "type in one the files that are listed and press enter"
  echo "then type in where on your PC you would like the file to be store"
  echo "once this is done you can get to work on the file you've selected!"
  read
  clear
  howTo
  break

  ;;
  3)
  clear
  echo "All you have to do to list all of the files in the current directory is press"
  echo "3 while on the repository menu."
  echo "You'll get a full list and can see what there is to work with!"
  read

  howTo
  break
  ;;
  4)
  clear
  echo "If you pick number four in the repository then you'll be able to edit a file"
  echo "inside of a text editor. "
  echo "Once you've picked the correct menu option, all you have to do is type the file"
  echo "you wish to edit and the file will open automatically."
  echo "don't worry if you want to keep using the terminal at the same time as this"
  echo "will continue to run in the background."
  read
    howTo
  break
  ;;
  5)
  clear
  echo "Selecting 5 from the menu will allow you to delete a file. but be warned, once it's gone"
  echo "it's gone for good!"
  echo "when you're inside of the delete menu. type in the file you wish to delete and it will"
  echo "delete it from the repository"
  echo "again be careful when using this as you don't want to lose data that you need!"
  read
  
  howTo
  break
  ;;
  6)
  clear
  echo "To see any changes that have been made when you've commited a file."
  echo "you'll need to head back to the main menu and in to the change log."
  echo "it will open up a text editor to show you exaclty what has been happening"
  echo "while commiting a file!"
  read
  howTo
  break
  ;;
  7) menu
  break
  ;;
esac



 


}


function repository 
{

#Shows the repository menu to the user 
    clear
    PS1='Please select an option: ' 
echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
echo "|1. To checkout all files on the repository.         |"
echo "|2. To commit changes to a file.                     |"
echo "|3. List contents of the repository                  |"
echo "|4. Edit a file                                      |"
echo "|5. Delete a file in the repository                  |"
echo "|6. Exit to main menu                                |"                   
echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "

#checks to see if the input is between 1 and 6 if it is then
echo ""
echo "Please select an option " 
echo "------------------------"
read input;


until (($input < 7 && $input > 0))
do
    echo "incorrect input, please try again"
    echo "please input a number between 1-6"
    read input;
done
case $input in
    1) checkout;;
    2) commit;;
    3) seeFiles;;
    4) editFile;;
    5) delete;;
    6) menu ;;
  *) echo invalid option;;
esac
break
}


function menu
{
  chmod 777 Menu

  #Checks to see if there is a log file. If there isn't one then create one.

    logFile=`pwd`"/""log.txt"

    if [ ! -f "$logFile" ]; then
        touch log.txt
    fi


clear

#first interface for the user along with the main menu
    echo -e " \e[31m-------------------------------------------------------- "
    echo -e " \e[97mHello $USER and welcome to Chris and Alexs SVN system."
    echo -e " \e[31m--------------------------------------------------------- "

    echo -e "\e[97m"
  
PS3='Please select an option: '
choices=("Repository" "Change log" "Help" "Quit")

select opt in "${choices[@]}"
do
    case $opt in
        "Repository")
            repository
            ;;
        "Change log")
            cat log.txt | more
            read
            menu
            ;;
        "Help")
                howTo
                ;;
        "Quit")
            break
            ;;
        *) echo invalid option;;
    esac
done
}

 

logging





